from flask import Flask, render_template, request, jsonify
import re, json, os

app = Flask(__name__)

DATA_FILE = "shopping_list.json"

# Load saved shopping list if file exists
if os.path.exists(DATA_FILE):
    with open(DATA_FILE, "r") as f:
        shopping_list = json.load(f)
else:
    shopping_list = {}

CATEGORIES = {
    "milk": "Dairy", "curd": "Dairy", "cheese": "Dairy",
    "apple": "Produce", "apples": "Produce", "banana": "Produce", "bananas": "Produce", "mango": "Produce",
    "bread": "Bakery", "buns": "Bakery", "cake": "Bakery",
    "chips": "Snacks", "biscuits": "Snacks", "cookies": "Snacks",
    "rice": "Grains", "wheat": "Grains", "flour": "Grains",
    "eggs": "Poultry", "chicken": "Poultry"
}

def save_list():
    with open(DATA_FILE, "w") as f:
        json.dump(shopping_list, f)

def add_item(item, qty=1):
    item = item.strip()
    if not item:
        return
    shopping_list[item] = shopping_list.get(item, 0) + max(1, qty)
    save_list()

def remove_item(item):
    item = item.strip()
    if item in shopping_list:
        del shopping_list[item]
        save_list()

def clear_list():
    shopping_list.clear()
    save_list()

def parse_command(command):
    command = command.lower().strip()

    # normalize synonyms
    command = command.replace("i need", "add ").replace("i want to buy", "add ").replace("add to my list", "add ")
    command = command.replace("delete", "remove ").replace("remove from my list", "remove ")

    # word numbers → digits
    words_to_nums = {
        "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
        "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10
    }
    for w, n in words_to_nums.items():
        command = re.sub(rf"\b{w}\b", str(n), command)

    if command.startswith("add") or " add " in command:
        qty_match = re.search(r"(\d+)", command)
        qty = int(qty_match.group(1)) if qty_match else 1
        item = re.sub(r"add|to my list|buy|purchase|\d+|x", "", command).strip()
        if not item:
            return "❌ Couldn't find item. Try 'Add 2 apples'."
        add_item(item, qty)
        return f"✅ Added {qty} {item}"

    if command.startswith("remove") or " remove " in command:
        item = re.sub(r"remove|from my list", "", command).strip()
        if not item:
            return "❌ Say 'Remove milk'."
        remove_item(item)
        return f"🗑️ Removed {item}"

    if "clear list" in command or "empty list" in command:
        clear_list()
        return "🧹 Cleared the shopping list"

    if command.startswith("find") or "search" in command:
        return "🔎 Searching items… (client-side)"

    return "❌ Command not understood. Try: 'Add 2 apples' or 'Remove milk'."

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/command", methods=["POST"])
def command():
    data = request.json or {}
    text = data.get("text", "")
    result = parse_command(text)

    payload = []
    for item, qty in shopping_list.items():
        cat = CATEGORIES.get(item.lower(), "Other")
        payload.append({"item": item, "qty": qty, "category": cat})

    return jsonify({"message": result, "list": payload})

if __name__ == "__main__":
    app.run(debug=True)

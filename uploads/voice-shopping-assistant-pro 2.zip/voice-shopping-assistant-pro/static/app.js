const products = [
  {id:1, name:"Organic Apples", price:120, tag:"Produce", img:"https://images.unsplash.com/photo-1567306226416-28f0efdc88ce"},
  {id:2, name:"Whole Wheat Bread", price:45, tag:"Bakery", img:"https://images.unsplash.com/photo-1549931319-a545dcf3bc73"},
  {id:3, name:"Almond Milk", price:199, tag:"Beverages", img:"https://images.unsplash.com/photo-1563630423918-6f9f1d7d3b91"},
  {id:4, name:"Free-range Eggs", price:80, tag:"Poultry", img:"https://images.unsplash.com/photo-1517957130951-04efd9dc18ec"},
  {id:5, name:"Granola Cookies", price:99, tag:"Snacks", img:"https://images.unsplash.com/photo-1514517220037-6805c4f38999"},
  {id:6, name:"Basmati Rice 5kg", price:499, tag:"Grains", img:"https://images.unsplash.com/photo-1604908554027-9e6f87cf9c7d"},
  {id:7, name:"Bananas", price:40, tag:"Produce", img:"https://images.unsplash.com/photo-1603833665858-e61d17a86224"},
  {id:8, name:"Cheddar Cheese", price:149, tag:"Dairy", img:"https://images.unsplash.com/photo-1552767059-8c30d3908a68"}
];

const grid = document.getElementById('grid');
const drawer = document.getElementById('drawer');
const listEl = document.getElementById('list');
const toast = document.getElementById('toast');
const search = document.getElementById('search');
const langSelect = document.getElementById('lang');

// ---------------- UI RENDER ----------------
function card(p){
  return `<div class="bg-white rounded-2xl p-3 card-hover shadow-md">
    <img src="${p.img}" alt="${p.name}" class="h-40 w-full object-cover rounded-lg">
    <div class="mt-3">
      <div class="font-semibold">${p.name}</div>
      <div class="text-sm text-gray-600">₹${p.price} • ${p.tag}</div>
      <div class="mt-3 flex space-x-2">
        <button class="px-3 py-2 rounded-xl bg-black text-white text-sm" onclick="quickAdd('${p.name}')">Add</button>
        <button class="px-3 py-2 rounded-xl border text-sm" onclick="openList()">View List</button>
      </div>
    </div>
  </div>`;
}

function renderGrid(items=products){
  grid.innerHTML = items.map(card).join('');
}
renderGrid();

search?.addEventListener('input', (e)=>{
  const q = e.target.value.toLowerCase();
  renderGrid(products.filter(p => p.name.toLowerCase().includes(q)));
});

function openList(){ drawer.classList.remove('hidden'); loadList(); }
document.getElementById('open-list')?.addEventListener('click', openList);
function closeList(){ drawer.classList.add('hidden'); }
window.closeList = closeList;

// ---------------- API COMM ----------------
async function sendCommand(text){
  const res = await fetch('/command', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({text})
  });
  const data = await res.json();
  toast.textContent = data.message;
  renderList(data.list);
  speak(data.message); // 🔊 voice feedback
}

function quickAdd(name){ 
  sendCommand(`add 1 ${name.toLowerCase()}`); 
  openList(); 
}
window.quickAdd = quickAdd;

// ---------------- LIST RENDER ----------------
function renderList(data){
  if(!data || data.length === 0){
    listEl.innerHTML = '<div class="text-gray-500">Your list is empty.</div>';
    return;
  }
  listEl.innerHTML = data.map(r => `
    <div class="flex items-center justify-between border-b py-3">
      <div>
        <div class="font-semibold">${r.item}</div>
        <div class="text-sm text-gray-500">${r.category}</div>
      </div>
      <div class="flex items-center space-x-2">
        <span class="px-3 py-1 bg-gray-100 rounded-full">x ${r.qty}</span>
        <button class="text-red-600" onclick="sendCommand('remove ${r.item.toLowerCase()}')">Remove</button>
      </div>
    </div>
  `).join('');
}

// ---------------- INIT ----------------
async function loadList(){
  const res = await fetch('/command', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({text:""})
  });
  const data = await res.json();
  renderList(data.list);
}
window.onload = loadList;

// ---------------- VOICE INPUT ----------------
function startRecognition(){
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if(!SR){ alert("⚠️ Speech recognition not supported in this browser. Use Google Chrome."); return; }

  const recog = new SR();
  recog.lang = langSelect.value || "en-US";
  recog.interimResults = false;
  recog.maxAlternatives = 1;

  recog.start();

  recog.onstart = () => { toast.textContent = "🎤 Listening..."; };

  recog.onresult = (e) => {
    const text = e.results[0][0].transcript;
    toast.textContent = `🎙️ You said: "${text}"`;
    sendCommand(text);
    openList();
  };

  recog.onerror = (e) => { toast.textContent = "❌ Error: " + e.error; };

  recog.onend = () => { toast.textContent += " (stopped)"; };
}
window.startRecognition = startRecognition;

// ---------------- VOICE FEEDBACK ----------------
function speak(text){
  if('speechSynthesis' in window){
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = langSelect.value || "en-US";
    window.speechSynthesis.speak(utter);
  }
}
